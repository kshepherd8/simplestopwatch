/************************************************************************//**
 *
 * \file SysTimer.c
 *
 * \addtogroup SysTimer SysTimer
 * \{
 *
 * \brief
 *
 * \note
 *
 * \author kjshepherd ()
 * \date 2014-09-10
 *
 ****************************************************************************/

/****************************************************************************
 *                              INCLUDE FILES                               *
 ****************************************************************************/
#include "SysTimer.h"
//#include "types.h"
#include "CommonDefines.h"

/****************************************************************************
 *                      PRIVATE TYPES and DEFINITIONS                       *
 ****************************************************************************/

/****************************************************************************
 *                              PRIVATE DATA                                *
 ****************************************************************************/
static SystemTimerDevice Timer;
static void * timerCallback;

/****************************************************************************
 *                             EXTERNAL DATA                                *
 ****************************************************************************/

/****************************************************************************
 *                     PRIVATE FUNCTION DECLARATIONS                        *
 ****************************************************************************/
//void set_timer(long long millisecs);
void register_callback(void * cb);
void execute_timer_callback(void);

/****************************************************************************
 *                     EXPORTED FUNCTION DEFINITIONS                        *
 ****************************************************************************/
SystemTimerDevice * SystemTimer_Init(void)
{
    Timer.SetTimer = set_timer;
    Timer.RegisterInterruptCallback = register_callback;
    return &Timer;
}

/****************************************************************************
 *                     PRIVATE FUNCTION DEFINITIONS                         *
 ****************************************************************************/
void set_timer(long long millisecs)
{
    //TODO: Your code here
}

void register_callback(void * cb)
{
    //TODO: Your code here
}

void execute_timer_callback(void)
{
    //TODO: Your code here
}

/************************************************************************//**
 * \brief
 * \param
 * \return
 ****************************************************************************/

/** \}*/
